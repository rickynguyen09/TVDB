package edu.floridapoly.mobiledeviceapps.spring20.tvdb;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "shows";
    private static final int DB_VERSION = 1;
    private Context mcontext;

    public DatabaseHelper(Context context){ super(context, DB_NAME, null, DB_VERSION); this.mcontext = context;}

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE shows (_id INTEGER PRIMARY KEY UNIQUE," +
                "TYPE TEXT," +
                "TITLE TEXT," +
                "DIRECTOR TEXT," +
                "_CAST TEXT," +
                "COUNTRY TEXT," +
                "DATE_ADDED TEXT," +
                "RELEASE_YEAR TEXT," +
                "RATING TEXT," +
                "DURATION INTEGER," +
                "GENRE TEXT," +
                "DESCRIPTION TEXT);");
        try {
            insertFromFile(mcontext, R.raw.tvdb, db);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public int insertFromFile(Context context, int resourceId, SQLiteDatabase db) throws IOException {
        // Reseting Counter
        int result = 0;

        // Open the resource
        InputStream insertsStream = context.getResources().openRawResource(resourceId);
        BufferedReader insertReader = new BufferedReader(new InputStreamReader(insertsStream));

        // Iterate through lines (assuming each insert has its own line and theres no other stuff)
        while (insertReader.ready()) {
            String insertStmt = insertReader.readLine();
            db.execSQL(insertStmt);
            result++;
        }
        insertReader.close();

        // returning number of inserted rows
        return result;
    }

}