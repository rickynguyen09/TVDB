package edu.floridapoly.mobiledeviceapps.spring20.tvdb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class Comedy_Screen extends AppCompatActivity {
    SQLiteOpenHelper DatabaseHelper;
    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comedy__screen);
        UserListView();
        //This is a test for me updating
    }
    public void UserListView(){

        ListView listView = (ListView)findViewById(R.id.ComedyList);

        try {
            DatabaseHelper = new DatabaseHelper(this);
            db = DatabaseHelper.getReadableDatabase();
            cursor = db.query("shows", new String[]{"_id", "TITLE", "GENRE"},
                    "GENRE" + " LIKE ?", new String[]{"%" + "Comedy" + "%"}, null, null, null);
            SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,
                    cursor, new String[]{"TITLE"}, new int[]{android.R.id.text1}, 0);
            listView.setAdapter(listAdapter);
        }catch(SQLiteException e ){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        final Intent intent = new Intent(this,DescriptionScreen.class);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                intent.putExtra("id", position + 1);
                startActivity(intent);
            }
        });
    }
}
