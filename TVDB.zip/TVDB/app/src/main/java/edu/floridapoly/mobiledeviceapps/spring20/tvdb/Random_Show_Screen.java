package edu.floridapoly.mobiledeviceapps.spring20.tvdb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class Random_Show_Screen extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    SQLiteOpenHelper DatabaseHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random__show__screen);
        DropdownMenu();
        UserListView();
    }
    public void UserListView(){

        ListView listView = (ListView)findViewById(R.id.RandomList);

        try {
            DatabaseHelper = new DatabaseHelper(this);
            db = DatabaseHelper.getReadableDatabase();
            cursor = db.query("shows", new String[]{"_id", "TITLE"},
                    null, null, null, null, null);
            SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,
                    cursor, new String[]{"TITLE"}, new int[]{android.R.id.text1}, 0);
            listView.setAdapter(listAdapter);
        }catch(SQLiteException e ){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        final Intent intent = new Intent(this,DescriptionScreen.class);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                intent.putExtra("id", position + 1);
                startActivity(intent);
            }
        });
    }

    public void DropdownMenu(){

        Spinner spinner = (Spinner) findViewById(R.id.MenuList);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.shows,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //String item = parent.getItemAtPosition(position).toString();
        if(parent.getItemAtPosition(position).equals("Action")){
            Intent intent = new Intent(Random_Show_Screen.this,Action_Screen.class);
            startActivity(intent);
        }

        if(parent.getItemAtPosition(position).equals("Comedy")){
            Intent intent = new Intent(Random_Show_Screen.this,Comedy_Screen.class);
            startActivity(intent);
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
