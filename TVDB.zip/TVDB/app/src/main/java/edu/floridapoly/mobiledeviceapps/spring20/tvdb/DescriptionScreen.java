package edu.floridapoly.mobiledeviceapps.spring20.tvdb;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DescriptionScreen extends AppCompatActivity {

    int id = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description_screen);
        id = getIntent().getIntExtra("id", 0);
        SQLiteOpenHelper userDatabaseHelper = new DatabaseHelper(this);
        try{
            SQLiteDatabase db = userDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT DESCRIPTION, _CAST, RATING, DURATION FROM shows WHERE _id = ?", new String[]{Integer.toString(id)});
            //Cursor cursor = db.query("shows", new String[]{"_id", "DESCRIPTION", "_CAST", "RATING", "DURATION"},
                    //"_id" + " LIKE ?", new String[]{Integer.toString(id)}, null, null, null);
            if(cursor.moveToFirst()){
                String descriptionText = cursor.getString(0);
                String castText = cursor.getString(1);
                String ratingText = cursor.getString(2);
                String durationText = cursor.getString(3);

                TextView description = (TextView) findViewById(R.id.descriptionText);
                description.setText(descriptionText);
                TextView cast = (TextView) findViewById(R.id.castText);
                cast.setText(castText);
                TextView rating = (TextView) findViewById(R.id.ratingText);
                rating.setText(ratingText);
                TextView duration = (TextView) findViewById(R.id.durationText);
                duration.setText(durationText);
            }
        }catch(SQLiteException e){
            Toast toast = Toast.makeText(this, "Database Unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }
    }


}